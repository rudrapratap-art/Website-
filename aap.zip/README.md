video_downloader/
│
├── app.py
├── requirements.txt
├── render.yaml
│
├── templates/
│   └── index.html
│
├── downloads/
│
└── README.md